package dao;

import connection.Connector;

import static constans.Constans.*;

import model.Dog;
import repositories.DogRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DogDAO implements DogRepository {

    public List<Dog> getAllDogs() throws SQLException {

        Connection conn = Connector.getConnect(URL_REMOTE, "devlab", "devlab");
        //   Connection conn  = Connector.getConnect(URL_LOCALHOST, LOGIN, PASS);
        String query = "select * from dogs";

        PreparedStatement preparedStatement = conn.prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();

        List<Dog> dogs = new ArrayList<Dog>();


        while (resultSet.next()) {

            Dog dog = new Dog();

            //   System.out.println(resultSet.getString(2));

            dog.setId(resultSet.getInt(1));
            dog.setName(resultSet.getString(2));
            dog.setAge(resultSet.getInt(3));
            dog.setBreed(resultSet.getString(4));
            dog.setDate(resultSet.getDate(5));
            dog.setOwner_id(resultSet.getInt(6));

            dogs.add(dog);

//         dogs.add(new Dog(
//                 resultSet.getInt(1),
//                 resultSet.getString(2),
//                 resultSet.getInt(3),
//                 resultSet.getString(4),
//                 resultSet.getDate(5),
//                 resultSet.getInt(6)
//         ));

        }

//        for (Dog d: dogs) {
////            System.out.println(d); }

//            dogs.forEach(d -> {
//                String a = d.getName().toUpperCase();
//                System.out.println(a);
//            });
//

        dogs.forEach(System.out::println);

        conn.close();

        return dogs;
    }


    @Override //zapobiega pomylkom w impl. metody
    public List<Dog> getDogsByName(String name) throws SQLException {

        Connection conn = Connector.getConnect(URL_REMOTE, "devlab", "devlab");

        String query = "select * from dogs where name =" + "'"+ name + "'";

        PreparedStatement preparedStatement = conn.prepareStatement(query);

        ResultSet rs = preparedStatement.executeQuery();

        List<Dog> dogs = new ArrayList<>();

        while (rs.next()) {

            Dog dog = new Dog();

            dog.setId(rs.getInt(1));
            dog.setName(rs.getString(2));
            dog.setAge(rs.getInt(3));
            dog.setBreed(rs.getString(4));
            dog.setDate(rs.getDate(5));
            dog.setOwner_id(rs.getInt(6));

            dogs.add(dog);

        }

        dogs.forEach(System.out::println);

        conn.close();

        return dogs;
    }

    @Override
    public void addNewDog(Dog dog) throws SQLException {

        Connection conn = Connector.getConnect(URL_REMOTE, "devlab", "devlab");

        String query = "insert into dogs(name, age, breed) values(?,?,?)";

        PreparedStatement preparedStatement = conn.prepareStatement(query);
        preparedStatement.setString(1,dog.getName());
        preparedStatement.setInt(2,dog.getAge());
        preparedStatement.setString(3,dog.getBreed());

        preparedStatement.executeUpdate();


    }

    public void updateDogName(String name, int id) throws SQLException {

    }

    public Dog getById(int id) throws SQLException {
        return null;
    }

}
