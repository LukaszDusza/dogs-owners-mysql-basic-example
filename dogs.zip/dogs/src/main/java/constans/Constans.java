package constans;

public class Constans {

    public static final String URL_LOCALHOST =
            "jdbc:mysql://localhost:3306/animals"
             + "?useSSL=false&true&useJDBCCompliantTimezoneShift=true&useLegacy" +
            "DatetimeCode=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";

    public static final String URL_REMOTE ="jdbc:mysql://" +
            "77.55.219.133:3306/animals" +
            "?useSSL=false" +
            "&true" +
            "&useJDBCCompliantTimezoneShift=true" +
            "&useLegacyDatetimeCode=false" +
            "&serverTimezone=UTC" +
            "&allowPublicKeyRetrieval=true";

    public static final String LOGIN = "root";
    public static final String PASS = "root";


}
